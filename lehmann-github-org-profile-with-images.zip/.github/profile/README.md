<div align="center">
  <img
    width="100%"
    alt="banner"
    src="https://capsule-render.vercel.app/api?type=waving&height=100&color=0:00A859,100:FFD100"
  />
</div>

<h3 align="center">
  Cooperativa Agrícola Ganadera Ltda. <br/> “Guillermo Lehmann”
</h3>

<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1200&center=true&vCenter=true&width=760&lines=Todo+lo+que+un+PROGRAMADOR+necesita+en+un+solo+lugar" alt="typing" />
  </a>
</p>

<p align="center">
  <img src="./assets/logo-green.png" alt="Logo Lehmann" height="80" />
  &nbsp;&nbsp;&nbsp;&nbsp;
  <img src="./assets/guille.png" alt="Guille" height="140" />
</p>

---

## 🧭 Nuestra propuesta

<div align="center">
  <strong>Todo lo que un PROGRAMADOR necesita en un solo lugar</strong>
</div>

> Repos, guías y lineamientos comunes para acelerar el trabajo de desarrollo dentro de la Cooperativa.

---

## 🤝 Cómo contribuir

1. Creá una **branch** desde `main`: `feature/mi-cambio` o `fix/bug-123`.
2. Commits con **Conventional Commits** (`feat:`, `fix:`, `docs:`, `chore:`…).
3. Abrí un **Pull Request** usando la plantilla.
4. Revisión de **CODEOWNERS** antes de hacer merge.

**Guías y políticas:**  
[CONTRIBUTING.md](../CONTRIBUTING.md) · [CODE_OF_CONDUCT.md](../CODE_OF_CONDUCT.md) · [SECURITY.md](../SECURITY.md) · [SUPPORT.md](../SUPPORT.md)

---

## 🔒 Seguridad

- Reportes de vulnerabilidades → **security@lehmann.example** (ver [SECURITY.md](../SECURITY.md))  
- No subas secretos: usá **GitHub Secrets / Environments**

---

## 📬 Contacto

- Mesa de Ayuda / Sistemas: **GLPI / Teams**  
- Web/LinkedIn institucional: _[agregar enlaces oficiales]_

---

<p align="center">
  <sub>Este README vive en <code>.github/profile/README.md</code> y define el perfil de la organización.</sub>
</p>
